
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><a href="<?php echo e(url('transaction/'. $temp->hashId .'/detail-list')); ?>"><i class="fas fa-arrow-alt-circle-left icon-link"></i></a> Transaction Detail Input</h1>
        </div>
        
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <form method="post" action="<?php echo e(url('transaction/' . $temp->hashid . '/detail-input')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-md-6 col-lg-6">
                                    <table width="100%">
                                        <tr>
                                            <td width="40%"><b>Nama Customer</b></td>
                                            <td>: <?php echo e($customer->name); ?></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6">
                                    <table width="100%">
                                        <tr>
                                            <td width="40%"><b>Keterangan</b></td>
                                            <td>: <?php echo e($temp->keterangan); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-md-8 col-lg-6">
                                    <table width="100%">
                                        <tr>
                                            <td width="35%"><b>Jenis Pengerjaan</b></td>
                                            <td class="pt-5">    
                                                <select id="jenisPengerjaan" name="jenisPengerjaan" class="form-control" onchange="getListPengerjaan()" required>
                                                    <option value="" selected disabled>Pilih Pengerjaan</option>
                                                    <option value="MT">Maintenance</option>
                                                    <option value="CK">Pengecekan</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="35%"><b>Inventory</b></td>
                                            <td class="pt-5">    
                                                <select id="inventoryCustomer" name="inventoryCustomer" class="form-control" onchange="getDetail()" required>
                                                    <option value="" selected disabled>Pilih Inventory</option>
                                                    <?php $__currentLoopData = $customer_inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($inventory->hashId); ?>" data-detail="<?php echo e(json_encode($inventory)); ?>"><?php echo e($inventory->kode_barcode); ?> - <?php echo e($inventory->nama_barang); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr class="headerInformations">
                                            <td width="35%"><b>Lokasi / Ruang</b></td>
                                            <td class="pt-5">    
                                                <input type="text" id="lokasi_form" name="lokasi_form" class="form-control" placeholder="Lokasi atau ruangan" required>
                                            </td>
                                        </tr>
                                        <tr class="headerInformations">
                                            <td width="35%"><b>Lantai</b></td>
                                            <td class="pt-5">    
                                                <input type="text" id="lantai_form" name="lantai_form" class="form-control" placeholder="Lantai" required>
                                            </td>
                                        </tr>
                                        <tr class="headerInformations">
                                            <td width="35%"><b>Merek</b></td>
                                            <td class="pt-5">    
                                                <input type="text" id="merk_form" name="merk_form" class="form-control" placeholder="Merk atau brand" required>
                                            </td>
                                        </tr>
                                        <tr class="headerInformations">
                                            <td width="35%"><b>Model (Label) Indoor</b></td>
                                            <td class="pt-5">    
                                                <input type="text" id="model_label_form" name="model_label_form" class="form-control" placeholder="Model" required>
                                            </td>
                                        </tr>
                                    </table>
                                </div>

                                <div class="col-12 mt-10 taskMaster" style="display: none; zoom: 0.9; overflow: auto;">
                                    <input type="hidden" id="noUrut" value="1">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Uraian Pengerjaan</th>
                                                <th>Satuan</th>
                                                <th>Value</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="taskListArea"></tbody>
                                    </table>
                                </div>
                                <div class="col-12 text-center mt-10 taskMaster" style="display: none;">
                                    <!-- <button type="button" class="btn btn-warning" onclick="addListPengerjaan()"><i class="fa fa-plus-circle"></i> Tambah Pengerjaan</button> -->
                                </div>
                            </div>
                        </div>
                        <div id="submitButtonArea" class="card-footer text-center" style="display: none;">
                            <button class="btn btn-primary"><i class="fas fa-save"></i> Simpan dan Lanjutkan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.select2-basic').select2();
        });

        function getDetail() {
            $('#cover-spin').fadeIn();
            let detail = $('#inventoryCustomer option:selected').data('detail');
            setTimeout(function() {
                $('#lokasi_form').val(detail.lokasi_form);
                $('#lantai_form').val(detail.lantai_form);
                $('#merk_form').val(detail.merk_form);
                $('#model_label_form').val(detail.model_label_form);

                $('.headerInformations').fadeIn();
                $('#cover-spin').fadeOut();
            }, 1000);
        }

        function getListPengerjaan() {
			$('#cover-spin').fadeIn();
			$.ajax({
				url: "<?php echo e(url('task/list')); ?>",
				method: "POST",
				headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
				data: {
					'type' : $('#jenisPengerjaan').val(),
				},
				success: function(response) {
                    $('.taskMaster').fadeIn();
                    $('#submitButtonArea').fadeIn();
                    $('#taskListArea').html(response);
                    $('#cover-spin').hide();
				},
				error: function(response) {
					var data = response.responseJSON;
					iziToast.error({
						title: '',
						position: 'topRight',
						message: 'Oops, something wrong !',
					});
					$('#cover-spin').hide();
				}
			});
        }

        function addListPengerjaan() {
            $('#cover-spin').fadeIn();
            let no_urut = parseInt($('#noUrut').val());
            $('#noUrut').val(no_urut + 1);
            $.ajax({
                url: "<?php echo e(url('task/list')); ?>",
                method: "POST",
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                data: {
                    'type' : $('#jenisPengerjaan').val(),
                    'no_urut' : $('#noUrut').val(),
                },
                success: function(response) {
                    $('#taskListArea').append(response);
                    $('#cover-spin').hide();
                },
                error: function(response) {
                    var data = response.responseJSON;
                    iziToast.error({
                        title: '',
                        position: 'topRight',
                        message: 'Oops, something wrong !',
                    });
                    $('#cover-spin').hide();
                }
            });
        }

        function removeTask(no) {
            $('#rowTask_' + no).remove();
        }

        function getSatuan(no) {
            let satuan = $('#taskList_' + no + ' option:selected').data('satuan');
            $('#satuan_' + no).html(satuan);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/transaction/detail_input.blade.php ENDPATH**/ ?>