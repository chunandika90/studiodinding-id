
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            
            <div class="row">
                <div class="col-sm-12 col-md-8 col-lg-8"><h1>Customer</h1></div>
                <div class="col-sm-12 col-md-4 col-lg-4"><a href="<?php echo e(url('customer/add')); ?>" class="btn btn-warning">Tambah Customer</a></div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                    <h4>Lists</h4>
                    <div class="card-header-form">
                        <form>
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search">
                            <div class="input-group-btn">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                            </div>
                        </div>
                        </form>
                    </div>
                    </div>
                    <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped">
                        <tr>
                            <th>Code</th>
                            <th>Nama</th>
                            <!-- <th>Instansi</th> -->
                            <th>Alamat</th>
                            <th>Informasi</th>
                            <th>Vendor</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($customer->code_customer); ?></td>
                                <td><?php echo e($customer->name); ?></td>
                                
                                <td><?php echo e($customer->alamat); ?></td>
                                <td><?php echo e($customer->handphone); ?></td>
                                <td><?php echo e($customer->vendor->nama); ?></td>
                                <td><a href="<?php echo e(url('customer/' . $customer->hashid . '/detail')); ?>" class="btn btn-primary">Detail</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/customer/list.blade.php ENDPATH**/ ?>