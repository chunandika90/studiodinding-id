
<?php $__env->startSection('body_content'); ?>

    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">

      <img src="<?php echo e(asset('assets/img/portfolio/porto-01-a.jpg')); ?>" alt="" data-aos="fade-in">
      <!-- <video autoplay muted loop data-aos="fade-in">
        <source src="assets/video/mim_dawn.mp4" type="video/mp4">
      </video> -->

      <div class="container d-flex flex-column align-items-center header-content">
        <h4 data-aos="fade-up" data-aos-delay="100">RUMAH BSD ANGGREK LOKA</h4>
        <p data-aos="fade-up" data-aos-delay="200">The wooden vertical facade helps to break the monotony of the massing, while controling the balance between the solid and transparent element in the facade.</p>
      </div>

    </section><!-- /Hero Section -->
    
    <!-- About Section -->
    <section id="about" class="about section">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <h4 class="h3-desc">This is an honest, elemental house that is informed by the land, the trees and the climate. It is our take on the Australian farmhouse and a simpler way of life.</h4>
            <p class="p-desc">Rob Mills</p>
          </div>
          <div class="col-lg-6 desc-project" data-aos="fade-up" data-aos-delay="250">
            <p>With this project, sited on 5 acres of Victorian countryside among ancient red gums, the client was looking for a home for her children and her horses. RMA took the iconic symbol of the Australian farmhouse and infused that vernacular with influences from around the world: the deep verandas nod to classic homesteads, while the use of an internal pond as a cooling device references the Middle East, and the honesty of the exposed timber form evokes Japanese architecture.</p>
            <p>This is a house that conveys a sort of innocence with its traditional hip roof and linear structure of recycled timbers. Economic materials such as plywood are used in interesting ways, concrete is polished and walls of glass frame the pastoral views. There is a quiet inventiveness at play.</p>
            <p>“By walking the land, we found the right orientation for the house, with all the main rooms open to both the view and to a northerly aspect,” says Mills.</p>
            <p>Ultimately it is about connection with the landscape – it is not a house to challenge its setting but rather to fit in, to be at one with the landscape, as though it was always there.</p>
          </div>
        </div>
        <div class="row gy-4 mb-5">
          <div class="col-lg-1"></div>
          <div class="col-lg-10" data-aos="fade-up" data-aos-delay="100">
            <a href="portfolio-rumah-bsd-anggrek-loka.html">
              <img src="<?php echo e(asset('assets/img/portfolio/porto-01-b.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Rumah BSD Anggrek Loka</h5> -->
            </a>
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <a href="#">
              <img src="<?php echo e(asset('assets/img/portfolio/porto-02-a.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kakolait To Go</h5> -->
            </a>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="250">
            <a href="#">
              <img src="<?php echo e(asset('assets/img/portfolio/porto-03-a.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kims Residence</h5> -->
            </a>
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-1"></div>
          <div class="col-lg-10" data-aos="fade-up" data-aos-delay="100">
            <a href="#">
              <img src="<?php echo e(asset('assets/img/portfolio/porto-04-a.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Permata Buana</h5> -->
            </a>
          </div>
        </div>
      </div>

    </section><!-- /About Section -->
    

    <footer id="footer" class="footer">

    <div class="container copyright text-center mt-4">
        <p>© <span>Copyright</span> <strong class="px-1 sitename">IT Team</strong> <span>All Rights Reserved</span></p>
        <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you've purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> Distributed by <a href=“https://themewagon.com>ThemeWagon
        </div>
    </div>

    </footer>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\studiodinding\resources\views/pages/portofolio/details.blade.php ENDPATH**/ ?>