
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Customer</h1>
        </div>
        
        <div class="row">
            <div class="col-12 col-md-6 col-lg-6">
            <div class="card">
                <form method="post" action="<?php echo e(url('customer/add')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="card-header">
                        <h4>Tambah Customer</h4>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Customer Group (*)</label>
                            <select name="customer_group" id="customer_group" class="form-control" required>
                                <option value="" selected disabled>Pilih Customer Group</option>
                                <?php $__currentLoopData = $customer_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($customer_group->id); ?>"><?php echo e($customer_group->code); ?> - <?php echo e($customer_group->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nama Sales (*)</label>
                            <select name="sales" id="sales" class="form-control" required>
                                <option value="" selected disabled>Pilih Sales</option>
                                <?php $__currentLoopData = $sales_pic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sales->id); ?>"><?php echo e($sales->name); ?> (<?php echo e($sales->nik); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nama Customer (*)</label>
                            <input type="text" name="customer" id="customer" class="form-control" placeholder="Nama" required="">
                        </div>
                        <div class="form-group">
                            <label>Contact Person (*)</label>
                            <input type="text" name="cp" id="cp" class="form-control" placeholder="CP" required="">
                        </div>
                        <div class="form-group">
                            <label>Alamat (*)</label>
                            <textarea name="address" id="address" class="form-control" placeholder="Alamat" required=""></textarea>
                        </div>
                        <div class="form-group">
                            <label>Informasi Kontak (*)</label>
                            <input type="text" name="handphone" id="handphone" class="form-control" placeholder="Informasi Kontak" required="">
                        </div>
                        
                        <div class="form-group">
                            <label>PIC Vendor (*)</label>
                            <select name="pic_vendor" id="pic_vendor" class="form-control" required>
                                <option value="" selected disabled>Pilih Vendor</option>
                                <?php $__currentLoopData = $vendor_pic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->nama); ?> (<?php echo e($vendor->contact_person); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>
                    <div class="card-footer text-right">
                        <a href="<?php echo e(url('customer')); ?>" class="btn btn-warning">Batal</a>
                        <button class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/customer/add.blade.php ENDPATH**/ ?>