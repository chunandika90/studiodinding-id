
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><a href="<?php echo e(url('transaction/'. $temp->hashId .'/detail-list')); ?>"><i class="fas fa-arrow-alt-circle-left icon-link"></i></a> Transaction Detail Input <small>(<?php echo e($customerInventory->kode_barcode . ' - ' . $customerInventory->nama_barang . ' / ' . $customerInventory->merk); ?>)</h1>
        </div>
        
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <!-- <form method="post" action="<?php echo e(url('transaction/' . $temp->hashid . '/detail-input')); ?>"> -->
                    <?php echo csrf_field(); ?>

                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-md-6 col-lg-6">
                                    <table width="100%">
                                        <tr>
                                            <td width="40%"><b>Nama Customer</b></td>
                                            <td>: <?php echo e($customer->name); ?></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6">
                                    <table width="100%">
                                        <tr>
                                            <td width="40%"><b>Keterangan</b></td>
                                            <td>: <?php echo e($temp->keterangan); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-md-8 col-lg-6">
                                    <table width="100%">
                                        <tr>
                                            <td width="35%"><b>Jenis Pengerjaan</b></td>
                                            <td class="pt-5">  
                                                <?php echo e($temp_transaction_detail[0]->type_trx == 'MT' ? 'Maintenance' : 'Pengecekan'); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="35%"><b>Inventory</b></td>
                                            <td class="pt-5">  
                                                <?php echo e($customerInventory->kode_barcode . ' - ' . $customerInventory->nama_barang . ' / ' . $customerInventory->merk); ?>  
                                            </td>
                                        </tr>
                                        <tr class="headerInformations">
                                            <td width="35%"><b>Lokasi / Ruang</b></td>
                                            <td class="pt-5">   
                                                <?php echo e($customerInventory->lokasi_form); ?>

                                            </td>
                                        </tr>
                                        <tr class="headerInformations">
                                            <td width="35%"><b>Lantai</b></td>
                                            <td class="pt-5">   
                                                <?php echo e($customerInventory->lantai_form); ?>

                                            </td>
                                        </tr>
                                        <tr class="headerInformations">
                                            <td width="35%"><b>Merek</b></td>
                                            <td class="pt-5">    
                                                <?php echo e($customerInventory->merk_form); ?>

                                            </td>
                                        </tr>
                                        <tr class="headerInformations">
                                            <td width="35%"><b>Model (Label) Indoor</b></td>
                                            <td class="pt-5">    
                                                <?php echo e($customerInventory->model_label_form); ?>

                                            </td>
                                        </tr>
                                    </table>
                                </div>

                                
                                <div class="col-12 mt-10">
                                    <form id="form-item">
                                        <input type="hidden" name="temp_transaction_id" value="<?php echo e($temp->hashid); ?>">
                                        <input type="hidden" name="customer_inventory_id" value="<?php echo e($customerInventory->hashid); ?>">
                                        <div class="row mt-10">
                                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-12 col-sm-12 col-md-6 col-lg-3 mt-10 text-center">
                                                    <div class="card">
                                                        <label>Foto <?php echo e($key+1); ?></label>
                                                        <?php if(count($photos) < 4): ?>
                                                            <input type="file" class="form-control" disabled>
                                                        <?php endif; ?>
                                                        <img src="<?php echo e(url('images/pengerjaan/' . $photo->photo)); ?>" class="img-previews mt-10" style="width: 100%">
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php for($i=0; $i<(4-count($photos)); $i++): ?> 
                                                <?php if($i==0): ?>
                                                    <div class="col-12 col-sm-12 col-md-6 col-lg-3 mt-10 text-center">
                                                        <div class="card">
                                                            <label>Pilih Foto <?php echo e(count($photos)+$i+1); ?></label>
                                                            <input type="file" class="form-control input-photo" id="photo_1">
                                                            <img src="<?php echo e(url('images/no-img.jpg')); ?>" class="img-preview mt-10" style="width: 100%">
                                                            <div class="text-center mt-10 mb-5">
                                                                <button class="btn btn-sm btn-warning"><i class="fas fa-plus-square"></i> Simpan</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="col-12 col-sm-12 col-md-6 col-lg-3 mt-10 text-center">
                                                        <div class="card">
                                                            <label>Pilih Foto <?php echo e(count($photos)+$i+1); ?></label>
                                                            <input type="file" class="form-control" name="photo_2" id="photo_2" disabled>
                                                            <img src="<?php echo e(url('images/no-img.jpg')); ?>" class="img-previews mt-10" style="width: 100%">
                                                            <div class="text-center mt-10 mb-5">
                                                                <button type="button" class="btn btn-disabled" disabled><i class="fas fa-plus-square"></i> Simpan</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endfor; ?>

                                            
                                        </div>
                                    </form>
                                </div>

                                <div class="col-12 mt-10 taskMaster" style="zoom: 0.9; overflow: auto;">
                                    <input type="hidden" id="noUrut" value="1">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Uraian Pengerjaan</th>
                                                <th>Satuan</th>
                                                <th>Value</th>
                                            </tr>
                                        </thead>
                                        <tbody id="taskListArea">
                                            <?php $__currentLoopData = $temp_transaction_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($row->task->pengerjaan); ?></td>
                                                    <td><?php echo e($row->task->satuan); ?></td>
                                                    <td><?php echo e($row->value_1); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div id="submitButtonArea" class="card-footer text-center" style="display: none;">
                            <button class="btn btn-primary"><i class="fas fa-save"></i> Simpan dan Lanjutkan</button>
                        </div>
                    </div>
                <!-- </form> -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $("#form-item").on("change", ".input-photo", function() {
            var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
            if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                iziToast.error({
                    title: '',
                    position: 'topRight',
                    message: "Format file hanya boleh JPG, JPEG atau PNG",
                });
                document.getElementById('photo_item_1').value= null;
                $('#form-item .img-id').attr('src', '<?php echo e(url("images/no-img.jpg")); ?>');
                return false;
            }

            if (this.files && this.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#form-item .img-preview').attr('src', e.target.result);
                };
                reader.readAsDataURL(this.files[0]);
            }
        })
        
        $("#form-item").on("submit", function() {
            $('#cover-spin').fadeIn();

            var formData = new FormData($('#form-item')[0]);
            var file_invoice = $('#form-item .input-photo')[0].files[0];

            if ($('#form-item .input-photo').length) var file = $('#form-item .input-photo')[0].files[0];
            if (typeof file != 'undefined') {
                ret = ImageTools.resize(file, {
                    width: 1000,
                    height: 1000
                }, function(blob, didItResize) {
                    formData.append('photo', blob);
                    
                    $.ajax({
                        url: "<?php echo e(url('transaction/' . $temp->hashId . '/detail/' . $customerInventory->hashId)); ?>/add_photo",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        data: formData,
                        type: 'POST',
                        contentType: false,
                        processData: false,
                        success: function(response) {
                            
                            iziToast.success({
                                title: '',
                                position: 'topRight',
                                message: 'Foto berhasil diupload',
                            });
                            location.reload();
                        },
                        error: function(response) {
                            var data = response.responseJSON;
                            iziToast.error({
                                title: '',
                                position: 'topRight',
                                message: data.error,
                            });

                            $('#cover-spin').hide();
                        }
                    });
                });
            } else {
                iziToast.error({
                    title: '',
                    position: 'topRight',
                    message: "File tidak valid",
                });
                $('#cover-spin').hide();
            }
            return false;
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/transaction/detail.blade.php ENDPATH**/ ?>