<div class="main-sidebar sidebar-style-2">
<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
    <!-- <a href="index.html">Main Tracker</a> -->
    <a href="<?php echo e(url('/')); ?>">18° Derajat</a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
    <a href="index.html">St</a>
    </div>
    <ul class="sidebar-menu">
    <li class="menu-header">Dashboard</li>
    <li class="dropdown">
        <a href="#" class="nav-link has-dropdown"><i class="fas fa-fire"></i><span>Dashboard</span></a>
        <ul class="dropdown-menu">
        <li class=active><a class="nav-link" href="index-0.html">General Dashboard</a></li>
        <li><a class="nav-link" href="index.html">Ecommerce Dashboard</a></li>
        </ul>
    </li>
    <li class="menu-header">Master Data</li>
    <li class=""><a class="nav-link" href="<?php echo e(url('customer')); ?>"><i class="fas fa-users"></i> <span>Customers</span></a></li>
    <!-- <li class=""><a class="nav-link" href="<?php echo e(url('sales')); ?>"><i class="fas fa-people-carry"></i> <span>Sales</span></a></li> -->
    
    <li class="menu-header">Transaksi</li>
    <li class=""><a class="nav-link" href="<?php echo e(url('transaction')); ?>"><i class="fas fa-people-carry"></i> <span>Pengerjaan</span></a></li>
    </ul>
    </aside>
</div><?php /**PATH C:\laragon\www\laravel_free\resources\views/sidebar.blade.php ENDPATH**/ ?>