
<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="rowTask_<?php echo e($no); ?>">
        <td style="min-width: 200px;">
            <?php echo e($task->pengerjaan); ?>

            <input type="hidden" name="taskList[]" id="taskList_<?php echo e($no); ?>" value="<?php echo e($task->hashId); ?>">
        </td>
        <td>
            <?php echo e($task->satuan); ?>

        </td>
        <td style="min-width: 150px;">
            <input type="text" id="valuePengerjaan_<?php echo e($no); ?>" name="valuePengerjaan[]" class="form-control" placeholder="">
        </td>
        <td class="text-center">
            <button type="button" class="btn btn-danger" onclick="removeTask('<?php echo e($no); ?>')"><i class="fas fa-trash-alt"></i></button>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/transaction/detail_input_pengerjaan.blade.php ENDPATH**/ ?>