
<?php $__env->startSection('body_content'); ?>

    
    <!-- About Section -->
    <section id="about" class="about section">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-4 desc-project" data-aos="fade-up" data-aos-delay="250">
            <p><h3 style="color: aliceblue;">Who we are <small style="font-weight: normal; font-size: 14px; color:darkgray">about us</small></h3></p>
            <p style="text-align: justify;">Studio Dinding is a multi-disciplinary team based in Jakarta, Indonesia. Studio Dinding offers total design solutions, architectural, interior, lighting, furnitures and building construction needs – which gives us advantages to deliver seamless design solution. We continually strive to enrich people’s lives through providing creative, comfortable, energy efficient and fresh solution as we strongly believe Studio Dinding’s work seeks to be timeless, unique and personal. Good design is about helping clients meet their needs and objectives. It is also about the way people feel when they experience it, a sense of meaning, connection and belonging. We listen to every little details and together we will craft your dream living places and work places. You are part of the team, let us work with you, not for you.</p>
          </div>
          <div class="col-lg-8" data-aos="fade-up" data-aos-delay="100">
            <img src="<?php echo e(asset('assets/img/team.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-7 col-md-4 col-sm-12" data-aos="fade-up" data-aos-delay="100"></div>
          <div class="col-lg-5 col-md-8 col-sm-12 desc-project" data-aos="fade-up" data-aos-delay="250" style="text-align: right;">
            <p><h3 style="color: aliceblue;">The Team <small style="font-weight: normal; font-size: 14px; color:darkgray">profile</small></h3></p>
            <p>Studio Dinding is a team of young creative-driven individuals<br>
with different professional backgrounds which gives us<br>
advantages to deliver total design solutions -<br>
architectural, interior, lighting, furnitures and building construction needs</p>
          </div>
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="100">
            <img src="<?php echo e(asset('assets/img/team_detail.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>
      </div>

    </section><!-- /About Section -->
    

    <footer id="footer" class="footer">

    <div class="container copyright text-center mt-4">
        <p>© <span>Copyright</span> <strong class="px-1 sitename">IT Team</strong> <span>All Rights Reserved</span></p>
        <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you've purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> Distributed by <a href=“https://themewagon.com>ThemeWagon
        </div>
    </div>

    </footer>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\studiodinding\resources\views/pages/about.blade.php ENDPATH**/ ?>