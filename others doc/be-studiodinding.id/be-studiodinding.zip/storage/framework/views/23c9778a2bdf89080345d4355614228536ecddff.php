
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><i class="fas fa-file"></i> Transaksi Baru</h1>
        </div>
        
        <div class="row">
            <div class="col-12 col-md-6 col-lg-6">
                <form method="post" action="<?php echo e(url('transaction/new')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Cari Customer</label>
                                <!-- <input type="text" name="fcustomer" id="fcustomer" class="form-control" placeholder="Kode barcode atau Handphone" required=""> -->
                                <select id="customerList" class="select2-basic form-control" name="customerList" onchange="getCustomer()">
                                    <option value="" selected disabled>Pilih Customer</option>
                                    <?php $__currentLoopData = $customerLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customerList->hashId); ?>" data-detail="<?php echo e(json_encode($customerList)); ?>"><?php echo e($customerList->code_customer . ' | ' . $customerList->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card" id="customer_detail" style="display: none;">
                        <div class="card-header">
                            <h4><i class="far fa-user"></i> Customer Data</h4>
                        </div>
                        <div class="card-body">
                            <table width="100%">
                                <tr>
                                    <td width="35%"><b>Nama</b></td>
                                    <td id="data_customer_name">~</td>
                                </tr>
                                <tr>
                                    <td width="35%"><b>Contact Person</b></td>
                                    <td id="data_customer_cp">~</td>
                                </tr>
                                <tr>
                                    <td width="35%"><b>Alamat</b></td>
                                    <td id="data_customer_alamat">~</td>
                                </tr>
                                <tr>
                                    <td width="35%"><b>Handphone</b></td>
                                    <td id="data_customer_handphone">~</td>
                                </tr>
                                <tr>
                                    <td width="35%"><b>Perusahaan</b></td>
                                    <td id="data_customer_perusahaan">~</td>
                                </tr>
                                <tr>
                                    <td width="35%"><b>Sales</b></td>
                                    <td  id="data_customer_sales">~</td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="card" id="service_type" style="display: none;">
                        <div class="card-body">
                            <div class="form-group" style="display: none;">
                                <label>Jenis Transaksi</label>
                                <!-- <input type="text" name="fcustomer" id="fcustomer" class="form-control" placeholder="Kode barcode atau Handphone" required=""> -->
                                <select id="serviceType" class="form-control">
                                    <option value="" selected disabled>Pilih Jenis Transaksi</option>
                                    <option value="MT">Maintenance</option>
                                    <option value="CK">Pengecekan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Keterangan Pengerjaan</label>
                                <textarea name="keterangan" id="keterangan" class="form-control" placeholder="Jenis barang. ex : split wall"></textarea>
                                
                            </div>
                        </div>
                        <div class="card-footer text-center">
                            <button class="btn btn-primary">Simpan dan Lanjutkan</button>
                        </div>
                    </div>
                    
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.select2-basic').select2();
        });

        function getCustomer() {
            $('#cover-spin').fadeIn();
            let customer = $('#customerList').val();
            let detail = $('#customerList option:selected').data('detail');
            setTimeout(function() {
                $('#data_customer_name').html(detail.name);
                $('#data_customer_cp').html(detail.contact_person);
                $('#data_customer_alamat').html(detail.alamat);
                $('#data_customer_handphone').html(detail.handphone);
                $('#data_customer_perusahaan').html(detail.instansi);
                $('#data_customer_sales').html(detail.sales.name + '  ('+detail.sales.nik+')');

                $('#customer_detail').fadeIn();
                $('#service_type').fadeIn();
                $('#cover-spin').fadeOut();
            }, 1000);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/transaction/new.blade.php ENDPATH**/ ?>