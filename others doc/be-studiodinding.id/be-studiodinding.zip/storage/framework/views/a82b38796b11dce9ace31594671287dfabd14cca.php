
<?php $__env->startSection('body_content'); ?>

    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">

      <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-02.jpg')); ?>" alt="" data-aos="fade-in">
      <!-- <video autoplay muted loop data-aos="fade-in">
        <source src="assets/video/mim_dawn.mp4" type="video/mp4">
      </video> -->

      <div class="container d-flex flex-column align-items-center header-content">
        <h4 data-aos="fade-up" data-aos-delay="100">WO HOUSE</h4>
      </div>

    </section><!-- /Hero Section -->
    
    <!-- About Section -->
    <section id="about" class="about section">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-7 desc-project" style="text-align: left;" data-aos="fade-up" data-aos-delay="100">
            <p> WO House is a residence of 3.5 stories with Modern Tropical Architecture, situated in long and narrow block on residential complex of North Jakarta. A defining characteristic of this dwelling lies in its inner courtyard, strategically positioned at the heart of the home, bridging the gap between the living and dining area. </p>
            <p>The pebble-adorned garden, accentuated by the presence of a Pule tree, seamlessly unites the realms of interior and exterior, fostering an impression of vast, interwoven space. This design not only imparts a refreshing ambiance but also bestows captivating vistas upon the adjoining areas</p>
          </div>
          <div class="col-lg-1 desc-project" style="text-align: left;" data-aos="fade-up" data-aos-delay="100"></div>
          <div class="col-lg-4 desc-project" style="text-align: left;" data-aos="fade-up" data-aos-delay="100">
            <div data-aos="fade-up" data-aos-delay="200"><small>Location : PIK, Jakarta Utara</small></div>
            <div data-aos="fade-up" data-aos-delay="200"><small>Land Size : 200 sqm</small></div>
            <div data-aos="fade-up" data-aos-delay="200"><small>Project Year: 2020</small></div>
          </div>
        </div>
        <div class="row gy-4 mb-5">
          <div class="col-lg-1"></div>
          <div class="col-lg-10" data-aos="fade-up" data-aos-delay="100">
            
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-03.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Rumah BSD Anggrek Loka</h5> -->
            
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-04.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kakolait To Go</h5> -->
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="250">
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-05.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kims Residence</h5> -->
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-1"></div>
          <div class="col-lg-10" data-aos="fade-up" data-aos-delay="100">
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-01.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Permata Buana</h5> -->
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-1"></div>
          <div class="col-lg-10" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-06.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Permata Buana</h5> -->
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-1"></div>
          <div class="col-lg-10" data-aos="fade-up" data-aos-delay="120">
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-07.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Permata Buana</h5> -->
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-08.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kakolait To Go</h5> -->
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="250">
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-09.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kims Residence</h5> -->
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-1"></div>
          <div class="col-lg-10" data-aos="fade-up" data-aos-delay="130">
              <img src="<?php echo e(asset('assets/img/portfolio/WO-HOUSE-10.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Permata Buana</h5> -->
          </div>
        </div>
      </div>

    </section><!-- /About Section -->
    

    <footer id="footer" class="footer">

    <div class="container copyright text-center mt-4">
        <p>© <span>Copyright</span> <strong class="px-1 sitename">IT Team</strong> <span>All Rights Reserved</span></p>
        <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you've purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> Distributed by <a href=“https://themewagon.com>ThemeWagon
        </div>
    </div>

    </footer>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\studiodinding\resources\views/pages/portofolio/details/wo_house.blade.php ENDPATH**/ ?>