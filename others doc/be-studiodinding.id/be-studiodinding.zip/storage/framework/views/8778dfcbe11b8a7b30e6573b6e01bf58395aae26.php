<!DOCTYPE html>
<html>
<head>
    <title>Notifikasi da</title>
</head>
<body>
    <p>Halo admin,</p>
    <p>Ada pesan baru nih dari pengunjung website kita.</p>
    <p>
        <table>
            <tr>
                <th>Nama</th>
                <td><?php echo e($data['name']); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo e($data['email']); ?></td>
            </tr>
            <tr>
                <th>Subject</th>
                <td><?php echo e($data['subject']); ?></td>
            </tr>
            <tr>
                <th>Pesan</th>
                <td><?php echo e($data['message']); ?></td>
            </tr>
        </table>
    </p>
    <p>Terima kasih</p>
</body>
</html><?php /**PATH C:\laragon\www\studiodinding\resources\views/emails/template_email.blade.php ENDPATH**/ ?>