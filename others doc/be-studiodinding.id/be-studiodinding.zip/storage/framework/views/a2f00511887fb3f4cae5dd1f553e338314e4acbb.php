
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Customer Detail</h1>
        </div>
        
        <div class="row">
            <div class="col-12 col-md-5 col-lg-5">
                <div class="card">
                    <div class="card-header">
                        <h4><i class="far fa-user"></i> Customer Data</h4>
                    </div>
                    <div class="card-body">
                        <table width="100%">
                            <tr>
                                <td width="35%"><b>Nama</b></td>
                                <td><?php echo e($customer->name); ?></td>
                            </tr>
                            <tr>
                                <td width="35%"><b>Contact Person</b></td>
                                <td><?php echo e($customer->contact_person); ?></td>
                            </tr>
                            <tr>
                                <td width="35%"><b>Alamat</b></td>
                                <td><?php echo e($customer->alamat); ?></td>
                            </tr>
                            <tr>
                                <td width="35%"><b>Handphone</b></td>
                                <td><?php echo e($customer->handphone); ?></td>
                            </tr>
                            <tr>
                                <td width="35%"><b>Perusahaan</b></td>
                                <td><?php echo e($customer->instansi); ?></td>
                            </tr>
                            <tr>
                                <td width="35%"><b>Vendor</b></td>
                                <td><?php echo e($customer->vendor->nama); ?> (<?php echo e($customer->vendor->contact_person); ?>)</td>
                            </tr>
                            <tr>
                                <td width="35%"><b>Sales</b></td>
                                <td><?php echo e($customer->sales->name); ?> (<?php echo e($customer->sales->nik); ?>)</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-7 col-lg-7">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-8">
                                <h4><i class="far fa-dropbox"></i> Customer Inventory</h4>
                            </div>
                            <div class="col-sm-4">
                                <a href="<?php echo e(url('customer/' . $customer->hashid . '/inventory/add')); ?>" class="btn btn-warning">Tambah Inventory</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body" style="overflow: auto; zoom: 0.9;">
                        <table class="table table-bordered">
                            <tr>
                                <th>Kode Barcode</th>
                                <th>Group</th>
                                <th>Barang</th>
                                <th>Brand</th>
                                <th>Spesification</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $customer->inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($inventory->kode_barcode); ?></td>
                                    <td><?php echo e($inventory->groupBarang->name); ?></td>
                                    <td><?php echo e($inventory->nama_barang); ?></td>
                                    <td><?php echo e($inventory->merk); ?></td>
                                    <td><?php echo e($inventory->spec); ?></td>
                                    <td><a href="<?php echo e(url('customer/detail/' . $customer->hashid)); ?>" class="btn btn-primary">Detail</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/customer/detail.blade.php ENDPATH**/ ?>