<html>
    <head>
        <style>
            body {
                font-family: 'Courier New', Courier, monospace;
            }

            td {
                font-size: 13px;
            }

            @media  print {
                @page  { margin: 0 20px; }
            }
        </style>
    </head>
    <body>
        <div style="width: 850px; padding-top:20px;">
            <table width="100%" border="1" cellspacing="0" cellpadding="10">
                <tr>
                    <td colspan="5">
                        <table width="100%">
                            <tr>
                                <td width="35%">
                                    <img src="<?php echo e(asset('images/18.jpg')); ?>" alt="logo" width="250px">
                                </td>
                                <td>
                                    <table width="100%">
                                        <tr>
                                            <td width="50%">
                                                <div><b>Nama Pelanggan</b></div>
                                                <?php echo e($customer->name); ?>

                                            </td>
                                            <td width="50%">
                                                <div><b>Jenis Pengerjaan</b></div>
                                                <?php echo e($temp_transaction_detail[0]->type_trx == 'MT' ? 'Maintenance' : 'Pengecekan'); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding-top: 20px;">
                                                <div><b>Inventory</b></div>
                                                <?php echo e($customerInventory->kode_barcode . ' - ' . $customerInventory->nama_barang . ' / ' . $customerInventory->merk); ?> 
                                            </td>
                                            <td style="padding-top: 20px;">
                                                <div><b>Tanggal Service</b></div>
                                                20 Februari 2025
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <tr>
                    <td>No</td>
                    <td>Uraian Pekerjaan</td>
                    <td>Satuan</td>
                    <td>Hasil Pengecekan</td>
                    <td rowspan="50" style="width: 150px;">
                        
                        <div style="text-align: center;">
                            <img src="<?php echo e(asset('images/pengerjaan/250220084742.jpg')); ?>" width="100%" style="padding:3px; border: 1px solid #eee;">
                            <div style="padding-top: 3px; padding-bottom: 10px;">Photo 1</div>
                        </div>
                                                <div style="text-align: center;">
                            <img src="<?php echo e(asset('images/pengerjaan/250220084751.jpg')); ?>" width="100%" style="padding:3px; border: 1px solid #eee;">
                            <div style="padding-top: 3px; padding-bottom: 10px;">Photo 2</div>
                        </div>
                                                <div style="text-align: center;">
                            <img src="<?php echo e(asset('images/pengerjaan/250220084759.jpg')); ?>" width="100%" style="padding:3px; border: 1px solid #eee;">
                            <div style="padding-top: 3px; padding-bottom: 10px;">Photo 3</div>
                        </div>
                                                <div style="text-align: center;">
                            <img src="<?php echo e(asset('images/pengerjaan/250220084810.jpg')); ?>" width="100%" style="padding:3px; border: 1px solid #eee;">
                            <div style="padding-top: 3px; padding-bottom: 10px;">Photo 4</div>
                        </div>
                    </td>
                </tr>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $temp_transaction_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($row->value_1): ?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($row->task->pengerjaan); ?></td>
                            <td><?php echo e($row->task->satuan); ?></td>
                            <td><?php echo e($row->value_1); ?></td>
                        </tr>
                        <?php
                            $no++;
                        ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <br>
            <div>
                <b>Catatan, Temuan / Rekomendasi :</b>
                <div style="font-size: 12px;;">
                    <ul>
                        <li>
                            AC menetes bisa sebabkan karena telat melakukan service pada AC, hal ini bisa muncul secara tiba-tiba. Tidak rutin dalam melakukan servis akan menyebabkan tersumbatnya saluran pembuangan air AC di karena penumpukan debu dan kotoran pada unit indoor AC.
                        </li>
                        <li>
                            Rutin membersihkan filter AC dan service AC bulanan. Dan hal seperti ini sebaiknya segera langsung diperbaiki, karena jika dibiarkan maka akan menimbulkan masalah-masalah lain pada AC. Proses AC yang tidak berjalan semestinya akan mengganggu komponen lainnya
                        </li>
                    </ul>
                </div>

                <div style="margin-top: 30px;">
                    <table width="100%">
                        <tr>
                            <td width="10%"></td>
                            <td width="30%">
                                Dibuat
                            </td>
                            <td width="30%">
                                Diperiksa
                            </td>
                            <td width="30%">
                                Disetujui
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/transaction/print_pengerjaan.blade.php ENDPATH**/ ?>