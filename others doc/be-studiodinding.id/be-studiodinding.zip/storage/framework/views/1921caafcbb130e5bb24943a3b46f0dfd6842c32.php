
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_content'); ?>
    
    
    <!-- About Section -->
    <section id="about" class="about section">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4 mt-4 mb-5">
          
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="100">
            
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-01.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Rumah BSD Anggrek Loka</h5> -->
            
          </div>
          <h1 data-aos="fade-up" data-aos-delay="100" style="color: #eee; margin-top:50px;"><center>WS Residence</center></h1>
          <div class="col-lg-3 desc-project" style="text-align: left;" data-aos="fade-up" data-aos-delay="100"></div>
          <div class="col-lg-6 desc-project" style="text-align: left;" data-aos="fade-up" data-aos-delay="100">
            <table width="100%" class="table">
              <tr>
                <td style="background: #000; color:#f5f5f5; font-size: 20px; font-weight: bold;">Location</td>
                <td style="background: #000; color:#aaa; font-size: 20px;">Jakarta, Indonesia</td>
              </tr>
              <tr>
                <td style="background: #000; color:#f5f5f5; font-size: 20px; font-weight: bold;">Land Size</td>
                <td style="background: #000; color:#aaa; font-size: 20px;">700 sqm</td>
              </tr>
              <tr>
                <td style="background: #000; color:#f5f5f5; font-size: 20px; font-weight: bold;">Project Year</td>
                <td style="background: #000; color:#aaa; font-size: 20px;">2022</td>
              </tr>
            </table>
          </div>
          <div class="col-lg-3 desc-project" style="text-align: left;" data-aos="fade-up" data-aos-delay="100"></div>
          
          <div class="col-lg-3 desc-project" style="text-align: left;" data-aos="fade-up" data-aos-delay="100"></div>
          <div class="col-lg-6 desc-project" style="text-align: left;" data-aos="fade-up" data-aos-delay="100">
            <p style="font-size: 20px;">
               Modern European style can be explained as a right balance between elegance & sophistication.
            </p>
            
            <p style="font-size: 20px;">The classical side of this style focuses on aesthetically pleasing beauty, soft in colour & intricate in every detail, whereas modern interior emphasises on simplicity, clean yet luxurious
            </p>
          </div>
          
        </div>

        <div class="row gy-4 mt-5 mb-5">
          
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="100">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-02.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-03a.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kakolait To Go</h5> -->
            
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="250">
            
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-03b.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kims Residence</h5> -->
            
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="100">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-04.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-05.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-07a.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kakolait To Go</h5> -->
            
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="250">
            
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-07b.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
              <!-- <h5 class="text-center">Kims Residence</h5> -->
            
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-06.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-08.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-09.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-10.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-11.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-12.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-13.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-14.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-15.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-16.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-17.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-18.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>

        <div class="row gy-4 mt-5 mb-5">
          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="110">
              <img src="<?php echo e(asset('assets/img/portfolio/ws-residence-19.jpg')); ?>" class="img-fluid rounded-1 mb-2 w-100" alt="">
          </div>
        </div>
      </div>
      
      <div style="margin-top:20px;"><center><a href="/portfolio" class="readMore" style="cursor: pointer;">ALL PROJECT</a></center></div>
    </section><!-- /About Section -->
    

    <footer id="footer" class="footer">

    <div class="container copyright text-center mt-4">
        <p>© <span>Copyright</span> <strong class="px-1 sitename">IT Team</strong> <span>All Rights Reserved</span></p>
        <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you've purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> Distributed by <a href=“https://themewagon.com>ThemeWagon
        </div>
    </div>

    </footer>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\studiodinding\resources\views/pages/portofolio/details/ws_residence.blade.php ENDPATH**/ ?>