
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><i class="fas fa-file-alt font25"></i> Transaction List</h1>
        </div>
        
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-8">
                                <h4>List</h4>
                            </div>
                            <div class="col-sm-4">
                                <a href="<?php echo e(url('transaction/new')); ?>" class="btn btn-warning">Buat Transaksi</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body" style="overflow: auto;">
                        <table class="table table-bordered">
                            <tr>
                                <th>Customer</th>
                                <th>Tanggal Transaksi</th>
                                <th>Keterangan</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($transaction->customer->code_customer . ' - ' . $transaction->customer->name); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($transaction->tgl_trx)->format('d F Y')); ?></td>
                                    <td><?php echo e($transaction->keterangan); ?></td>
                                    <td><a href="<?php echo e(url('transaction/' . $transaction->hashId . '/detail-list')); ?>" class="btn btn-primary">Detail</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function getDetail() {
            $('#cover-spin').fadeIn();
            let detail = $('#inventoryCustomer option:selected').data('detail');
            setTimeout(function() {
                $('#lokasi_form').val(detail.lokasi_form);
                $('#lantai_form').val(detail.lantai_form);
                $('#merk_form').val(detail.merk_form);
                $('#model_label_form').val(detail.model_label_form);

                $('.headerInformations').fadeIn();
                $('#cover-spin').fadeOut();
            }, 1000);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/transaction/lists.blade.php ENDPATH**/ ?>