
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Customer</h1>
        </div>
        
        <div class="row">
            <div class="col-12 col-md-6 col-lg-6">
            <div class="card">
                <form method="post" action="<?php echo e(url('customer/' . $id . '/inventory/add')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="card-header">
                        <h4>Tambah Inventory Barang (<?php echo e($customer->name); ?>)</h4>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Group Barang (*)</label>
                            <select name="group_barang" id="group_barang" class="form-control" required>
                                <option value="" selected disabled>Pilih Group Barang</option>
                                <?php $__currentLoopData = $group_barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($group_barang->id); ?>"><?php echo e($group_barang->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nama Barang (*)</label>
                            <input type="text" name="barang" id="barang" class="form-control" placeholder="Nama Barang" required="">
                        </div>
                        <div class="form-group">
                            <label>Merk (*)</label>
                            <input type="text" name="merk" id="merk" class="form-control" placeholder="Merk atau Brand" required="">
                        </div>
                        <div class="form-group">
                            <label>Spesifikasi (*)</label>
                            <textarea name="spec" id="spev" class="form-control" placeholder="Spec Barang" required=""></textarea>
                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <a href="<?php echo e(url('customer')); ?>" class="btn btn-warning">Batal</a>
                        <button class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/customer/add_inventory.blade.php ENDPATH**/ ?>