
<?php $__env->startSection('body_content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><a href="<?php echo e(url('transaction')); ?>"><i class="fas fa-arrow-alt-circle-left icon-link"></i></a> Transaction Detail Input <small>(<?php echo e($temp->keterangan); ?>)</small></h1>
        </div>
        
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card" style="background-color: #E8EAF6;">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12 col-md-6 col-lg-6">
                                <table width="100%">
                                    <tr>
                                        <td width="40%"><b>Nama Customer</b></td>
                                        <td>: <?php echo e($customer->name); ?></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-12 col-md-6 col-lg-6">
                                <table width="100%">
                                    <tr>
                                        <td width="40%"><b>Keterangan</b></td>
                                        <td>: <?php echo e($temp->keterangan); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-8">
                                <h4><i class="far fa-dropbox"></i> List Barang Pengerjaan</h4>
                            </div>
                            <div class="col-sm-4">
                                <a href="<?php echo e(url('transaction/' . $temp->hashId . '/detail-input')); ?>" class="btn btn-warning">Tambah Pengerjaan</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body" style="overflow: auto; zoom: 0.9;">
                        <table class="table table-bordered">
                            <tr>
                                <th>Jenis Pengerjaan</th>
                                <th>Barang</th>
                                <th>Tanggal Pengerjaan</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $temp->details()->groupBy('customer_inventory_id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($temp_detail->type_trx == 'MT' ? 'Maintenance' : 'Pengecekan'); ?> (<?php echo e($temp_detail->type_trx); ?>)</td>
                                    <td><?php echo e($temp_detail->customerInventory->kode_barcode); ?> - <?php echo e($temp_detail->customerInventory->nama_barang); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($temp_detail->tanggal_pengerjaan)->format('d F Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('transaction/' . $temp->hashId . '/detail/' . $temp_detail->customerInventory->hashid)); ?>" class="btn btn-primary">Detail</a>
                                        
                                        <a href="<?php echo e(url('transaction/' . $temp->hashId . '/print/' . $temp_detail->customerInventory->hashid)); ?>" class="btn btn-primary"><i class="fas fa-print"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function getDetail() {
            $('#cover-spin').fadeIn();
            let detail = $('#inventoryCustomer option:selected').data('detail');
            setTimeout(function() {
                $('#lokasi_form').val(detail.lokasi_form);
                $('#lantai_form').val(detail.lantai_form);
                $('#merk_form').val(detail.merk_form);
                $('#model_label_form').val(detail.model_label_form);

                $('.headerInformations').fadeIn();
                $('#cover-spin').fadeOut();
            }, 1000);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_free\resources\views/pages/transaction/new_detail.blade.php ENDPATH**/ ?>